<div class="row">
  <div class="col text-center">
    <div class="row float-right align-middle">
      <div class="col">
        <span class="text-white">SIGUENOS:</span>

        <a href="https://www.facebook.com/ProductosRamo" title="Facebook" target="_blank" class="btn btn-social-icon btn-facebook" style="border-radius: 50%; background-color:#f2ce3e">
          <span class="fa fa-facebook" style="color:#266fbf"></span>
        </a>
        <a href="https://www.instagram.com/productosramo" title="Instagram" target="_blank" class="btn btn-social-icon btn-instagram" style="border-radius: 50%; background-color:#f2ce3e">
          <span class="fa fa-instagram" style="color:#266fbf"></span>
        </a>
        <a href="https://twitter.com/ramocolombia" target="_blank" title="Twitter" class="btn btn-social-icon btn-twitter" style="border-radius: 50%; background-color:#f2ce3e">
          <span class="fa fa-twitter" style="color:#266fbf"></span>
        </a>
        <a href="https://www.youtube.com/channel/UCv5QGIpsfM1xlPzp0F4RrFQ" title="Youtube" target="_blank" class="btn btn-social-icon btn-youtube" style="border-radius: 50%; background-color:#f2ce3e">
          <span class="fa fa-youtube" style="color:#266fbf"></span>
        </a>
        <a href="tel:018000180535" target="_blank" title="Linea Nacional" class="btn btn-social-icon btn-youtube" style="border-radius: 50%; background-color:#f2ce3e">
          <span class="fa fa-phone" style="color:#266fbf"></span>
        </a>
      </div>
      
    </div>
    <div class="row" style="width: 100%;">
      <div class="col">
        <img alt="Image" clsss="responsive-image" src="assets/img/logo.png" style="width: 25%;"/>
      </div>
      
    </div>
  </div>
</div>