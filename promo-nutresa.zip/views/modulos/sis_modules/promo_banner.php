
<div class="container-fluid text-center" style="background-color: #e9092b">
  <a href="https://tiendaramo.com/" target="_blank">
   
      <img src="assets/img/botontiendaramo.jpg" alt="Promo" style="max-height:40px; max-width: 100%;">
   
    
  </a>
  
</div>