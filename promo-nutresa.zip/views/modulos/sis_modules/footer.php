<footer class="bg-gray text-light footer-long">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-3 text-center">
                    <img alt="Logo" src="<?php echo LOGO_NAME?>" class="mb-4" style="width:240px"/>
                    
                </div>
                <div class="col-12 col-lg-6 text-center pt-4">
                    <h6>
                        <a href="#" data-toggle="modal" data-target="#terminosModal">
                            POLÍTICA DE TRATAMIENTO DE DATOS PERSONALES
                        </a>    
                        LÍNEA DE SERVICIO AL CLIENTE COLOMBIA 018000521155
                    </h6>
                </div>

                <div class="col-12 col-md-3 text-center pt-4">
                        <a href="https://www.facebook.com/" title="Facebook" target="_blank" class="btn btn-social-icon btn-facebook" style="border-radius: 50%; background-color:#f2ce3e">
                <span class="fa fa-facebook" style="color:#266fbf"></span>
                </a>
                <a href="https://www.instagram.com/" title="Instagram" target="_blank" class="btn btn-social-icon btn-instagram" style="border-radius: 50%; background-color:#f2ce3e">
                <span class="fa fa-instagram" style="color:#266fbf"></span>
                </a>
                </div>

            
            </div>

            <div class="row">
                <div class="col-12 text-center">
                    <p class="text-muted">
                        &copy; Nutresa <?php echo date('Y');?> 
                    </p>
                </div>
            </div>
            <!--end of row-->
        </div>
  
    </footer>