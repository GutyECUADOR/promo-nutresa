<div id="whatspopover" class="float" data-container="body" data-toggle="popover" data-placement="left" data-content="CENTRO DE CONTACTO.">
    <a style="color: white;" href="https://api.whatsapp.com/send?phone=+573203192388&text=Hola! Quisiera más información sobre la promoción."  target="_blank">
    <i class="fa fa-whatsapp my-float"></i>
</div>
