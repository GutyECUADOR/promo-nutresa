<div id="whatspopover" class="float"  data-container="body" data-toggle="popover" data-placement="left" data-content="CENTRO DE CONTACTO.">
    <a style="color: white;" href="https://api.whatsapp.com/send?phone=+573223542797&text=Hola%21%20Quisiera%20m%C3%A1s%20informaci%C3%B3n%20sobre%20la%20promocion%20."  target="_blank">
    <i class="fa fa-whatsapp my-float"></i>
</div>
