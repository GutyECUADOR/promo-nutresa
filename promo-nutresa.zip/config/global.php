<?php
/* Configurar aqui todas las variables globales a utilizar*/
define("APP_NAME", "");
define("APP_UNIQUE_KEY", "PromoNutresa2021$");
define("EMPRESA_NAME", "");
define("LOGO_NAME", "./assets/img/logo.png");
define("DEFAULT_DBName", "nutresa");
define("APP_VERSION", "1.0.1");
define("ROOT_PATH","");   //Root del proyecto

/*URL Body Email*/
define("LOGO_ONLINE","");
define("SITIOWEB_ONLINE","");
define("BODY_EMAIL_TEXT","");
